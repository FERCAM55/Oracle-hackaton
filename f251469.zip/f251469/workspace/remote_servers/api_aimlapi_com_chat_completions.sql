prompt --workspace/remote_servers/api_aimlapi_com_chat_completions
begin
--   Manifest
--     REMOTE SERVER: api-aimlapi-com-chat-completions
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>64571566319293017787
,p_default_application_id=>251469
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FERCAM'
);
wwv_imp_workspace.create_remote_server(
 p_id=>wwv_flow_imp.id(64607234957854525189)
,p_name=>'api-aimlapi-com-chat-completions'
,p_static_id=>'api_aimlapi_com_chat_completions'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('api_aimlapi_com_chat_completions'),'https://api.aimlapi.com/chat/completions')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('api_aimlapi_com_chat_completions'),'')
,p_server_type=>'WEB_SERVICE'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('api_aimlapi_com_chat_completions'),'')
,p_remote_sql_default_schema=>nvl(wwv_flow_application_install.get_remote_server_default_db('api_aimlapi_com_chat_completions'),'')
,p_mysql_sql_modes=>nvl(wwv_flow_application_install.get_remote_server_sql_mode('api_aimlapi_com_chat_completions'),'')
,p_prompt_on_install=>false
,p_ai_is_builder_service=>false
,p_ai_model_name=>nvl(wwv_flow_application_install.get_remote_server_ai_model('api_aimlapi_com_chat_completions'),'')
,p_ai_http_headers=>nvl(wwv_flow_application_install.get_remote_server_ai_headers('api_aimlapi_com_chat_completions'),'')
,p_ai_attributes=>nvl(wwv_flow_application_install.get_remote_server_ai_attrs('api_aimlapi_com_chat_completions'),'')
);
wwv_flow_imp.component_end;
end;
/
