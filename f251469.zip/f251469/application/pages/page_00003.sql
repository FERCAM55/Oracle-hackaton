prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>64571566319293017787
,p_default_application_id=>251469
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FERCAM'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'hello'
,p_alias=>'HELLO'
,p_step_title=>'hello'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp.component_end;
end;
/
