prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>64571566319293017787
,p_default_application_id=>251469
,p_default_id_offset=>0
,p_default_owner=>'WKSP_FERCAM'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Tips para IA'
,p_alias=>'TIPS-PARA-IA'
,p_step_title=>'Tips para IA'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'27'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64926566322630336574)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64575167200208349917)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(64573895824391349805)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(64576188441054349986)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64926567091481336576)
,p_plug_name=>'Tips para IA'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(64574460988871349838)
,p_plug_display_sequence=>10
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return q''~',
'select 1 as "ID",',
unistr('       ''\00A1No tengas miedo de preguntar! La IA puede ayudarte a aprender cosas nuevas. Si no sabes algo, simplemente preg\00FAntalo. Cuanto m\00E1s preguntas hagas, m\00E1s aprender\00E1s.'' as test'),
'  from sys.dual',
'union all',
'select 2 as "ID",',
unistr('       ''La IA puede ayudarte con tus tareas escolares. Si no entiendes algo de matem\00E1ticas o historia, p\00EDdele que te explique o te d\00E9 ejemplos.'' as test'),
'  from sys.dual',
'union all',
'select 3 as "ID",',
unistr('       ''Puedes usar la IA para crear cosas divertidas, como cuentos, dibujos o incluso juegos. \00A1Deja volar tu imaginaci\00F3n!'' as test'),
'  from sys.dual',
'union all',
'select 4 as "ID",',
unistr('       ''Existen juegos interactivos con IA que te ense\00F1an mientras juegas. Puedes aprender de todo, desde idiomas hasta ciencias, \00A1y es muy divertido!'' as test'),
'  from sys.dual',
'union all',
'select 5 as "ID",',
unistr('       ''La IA puede ayudarte a ser m\00E1s organizado. Usa asistentes inteligentes para recordarte tus tareas o actividades importantes, como hacer la tarea o practicar deportes.'' as test'),
'  from sys.dual',
'union all',
'select 6 as "ID",',
unistr('       ''Si te gusta la tecnolog\00EDa, la IA puede ayudarte a crear tus propios proyectos, como peque\00F1os robots o juegos sencillos. \00A1Puedes aprender programaci\00F3n y divertirte al mismo tiempo!'' as test'),
'  from sys.dual',
'union all',
'select 7 as "ID",',
unistr('       ''Aprender c\00F3mo funciona la IA es tan divertido como usarla. Preg\00FAntale a la IA c\00F3mo toma decisiones o c\00F3mo reconoce im\00E1genes, y empezar\00E1s a entender m\00E1s sobre tecnolog\00EDa.'' as test'),
'  from sys.dual',
'union all',
'select 8 as "ID",',
'       ''Si quieres mejorar en algo, como tocar un instrumento, aprender un idioma o jugar mejor al ajedrez, la IA puede ayudarte con tutoriales o consejos.'' as test',
'  from sys.dual',
'union all',
'select 9 as "ID",',
unistr('       ''La IA puede ser como un amigo que te ayuda a descubrir cosas nuevas y siempre est\00E1 dispuesto a explicarte todo lo que necesites.'' as test'),
'  from sys.dual',
'union all',
'select 10 as "ID",',
unistr('       ''La IA es muy \00FAtil, pero es importante que siempre cuides tu privacidad. No compartas informaci\00F3n personal como tu nombre completo o direcci\00F3n, \00A1s\00E9 cuidadoso!'' as test'),
'  from sys.dual',
'~'';'))
,p_template_component_type=>'REPORT'
,p_lazy_loading=>false
,p_plug_source_type=>'TMPL_THEME_42$CONTENT_ROW'
,p_plug_query_num_rows=>15
,p_plug_query_num_rows_type=>'SET'
,p_show_total_row_count=>false
,p_landmark_type=>'region'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'APPLY_THEME_COLORS', 'Y',
  'DESCRIPTION', 'Nunc sit amet nunc quis magna ornare suscipit. Etiam aliquet maximus sapien, at sagittis sem gravida nec.',
  'DISPLAY_AVATAR', 'N',
  'DISPLAY_BADGE', 'N',
  'HIDE_BORDERS', 'N',
  'OVERLINE', 'Category',
  'REMOVE_PADDING', 'N',
  'TITLE', 'Lorem ipsum dolor sit amet')).to_clob
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(64926567520629336580)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>10
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(64926568050002336581)
,p_name=>'TEST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TEST'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_display_sequence=>20
,p_is_required=>false
,p_use_as_row_header=>false
,p_is_primary_key=>false
,p_include_in_export=>false
);
wwv_flow_imp.component_end;
end;
/
